/* Simulation
 * Sensor sample interval is 500 ms. Nominal sensor value random-walks up
 * and down from an initial value of 100; sensor "noise" = 5.
 *
 * Text output of readings and associated nominal values are output on
 * console and can be redirected to a log file for experimentation.
 */
import java.util.*;

public class Simulation {
  private DataDisplay display;
  private SensorSim[] sensors;
  private double sensorNom;       //nominal value -- random-walks
  private final double sensorErr; //fixed

  public Simulation(double n, double e, int nSens) { //constructor
    sensors = new SensorSim[nSens];
    sensorNom = n;
    sensorErr = e;
    display = new DataDisplay();
    runSimulation();
  }

  public void runSimulation()  {
    Random rng = new Random();
    sensors[0] = new FaultySensorSim(sensorNom, sensorErr, 10000, 200);
    for (int k=1; k < sensors.length; k++)
      sensors[k] = new SensorSim(sensorNom, sensorErr);
    for (int k=0; k < sensors.length; k++)
      sensors[k].start();
    System.out.println("Reading: Nomnl:  diff");
    while(true) {
      double rdg = combinedRdg();
      System.out.printf("%7.2f: %5.1f: %4.1f\n", rdg, sensorNom, rdg-sensorNom);
        //sensor:output(nominal):difference on console; can be redirected to log
      display.update(rdg, sensorNom); 

      if (rng.nextBoolean())  //nominal sensor output random-walks up & down
        sensorNom++;
      else
        sensorNom --;
      for (int k=0; k < sensors.length; k++)
        sensors[k].setNominal(sensorNom);

      try {  // 0.5-second sleep
        Thread.sleep(500);
      } catch (InterruptedException ix) {}
    }
  }

  //Combine all the sensors' readings
  private double combinedRdg() {
    double rslt = 0.0;
    for (int k=0; k < sensors.length; k++)
      rslt += sensors[k].getRdg();
    rslt /= sensors.length;
    return rslt;
  }

  public static void main(String[] args) {
    new Simulation(100, 5, 3);
  } 

} //end class Simulation
