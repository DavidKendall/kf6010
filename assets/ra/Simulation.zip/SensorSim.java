/*
 * SensorSim - Simulate a sensor with "noise".
 *
 * Value returned by getRdg() is nominal value =/- a random noise value,
 * whose standard deviation is parameter sd. Random noise is simulated
 * with help of Random.nextGaussian() which returns a pseurandom normally
 * distributed number with mean = 0 and SD = 1.
   standard cumulative probability lookup table. The table,
 * a static array of double, is initialised from file cumProbs.txt and is
 * binary-searched for a z-value corresponding to a randomly generated 
 * probability.
 * 
 * Constructor parameters: initial nominal value, std devn (simulated noise).
 *
 * Nominal value is adjustible via setNominal().
 */
import java.util.*;
import java.io.*;

public class SensorSim extends Thread {
  protected double nominal, sd, z;
  protected int refreshInterval;
  protected Random rng;
  protected boolean running;

  // ------------------ instance methods --------------------

  public SensorSim(double n, double d) {
    nominal = n; sd = d;
    rng = new Random();
    running = true;
  }

  public void swOff() {running = false; }

  public void   setNominal(double n) { nominal = n;    }
  public double getNominal()         { return nominal; }

  public void run() {
    int k = 0;
    while(running) {
      z = rng.nextGaussian();
      k++;
      if (k%100 == 0) rng = new Random(); //re-initiallise RNG
      try {
        Thread.sleep(200);
      } catch (InterruptedException ix) {}
    }
  }

  public double getRdg() {
    return nominal + z*sd;
  }

} //end class

/*
 * A noisy sensor as above, but which sporadically returns a rubbish value
 * instead of the the correctly simulated one. The fault occurs sporadically  
 * (a Poisson process) and persists for a random proportion of the interval
 * until the next occurrence.
 * 
 * The rubbish value and (Poisson) frequency of the fault are configurable.
 */
class FaultySensorSim extends SensorSim {
  private long faultTime, faultDuration, faultInterval;
  private double faultValue;

  public FaultySensorSim(double n, double d, long fInterval, double fValue) {
    super(n, d);
    faultInterval = fInterval;
    faultValue = fValue;
    faultDuration = - (long)(Math.log(rng.nextDouble())*fInterval);
    faultTime = System.currentTimeMillis() + faultDuration;
    faultDuration *= rng.nextDouble() * 0.5;
  }

  public double getRdg() { //overriding method
    long now = System.currentTimeMillis();
    if (now >= faultTime) { //a fault
      if (now >= faultTime + faultDuration) {//recalc time to nxt fault, duration
        faultDuration = - (long)(Math.log(rng.nextDouble())*faultInterval);
        faultTime = now + faultDuration;
        faultDuration *= rng.nextDouble() * 0.5;
      }
      return faultValue;
    }
    else
      return nominal + z*sd;
  }

} //end class
