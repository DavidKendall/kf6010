/* DataDisplay
 *   for Simulation. Display simulated sensor readings from a SensorSim
 * as a time-series trace on a graph; also displays nominal sensor value.
 */
import java.awt.*;
import javax.swing.*;
import java.util.*;

public class DataDisplay extends JPanel {
  private Vector<Double> trace; //values to be displayed on graph
  private double sensorNom = 0;
  private Color dkGreen = Color.green.darker();
  private Color grdClr = new Color(180, 180, 180);

  public DataDisplay() { //constructor
    JFrame app = new JFrame("Sensor Data Display (grid = 10)");
    app.add(this, BorderLayout.CENTER);

    app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    app.setSize(700, 500);
    app.setVisible(true);

    trace = new Vector<Double>();
  }

  public void update(double rdg, double sNom)  {
    if (trace.size() >= getWidth()) { //if full width of window used,
      trace = new Vector<Double>();   //clear trace and start again
    }
    trace.addElement(rdg);
    sensorNom = sNom;
    repaint();
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    int h = getHeight(), w = getWidth(), hy = h-10; //window dims, x-axis pos
    g.setColor(grdClr); 
    for (int k = 0; k < hy; k += 20)                //grid lines
      g.drawLine(0, hy-k, w, hy-k);
    for (int k = 0; k < w; k += 20)
      g.drawLine(k, 0, k, h);
    g.setColor(Color.black);
    for (int k = 0; k < hy; k += 20)                //y-axis labels
      g.drawString(String.format("%d",k/2), 0, hy-k);
    g.setColor(Color.red);
    g.drawLine(0, hy, w, hy);                       //axes
    g.drawLine(0, 0, 0, h);
    g.setColor(dkGreen);                            //show nominal value 
    int ny = hy-(int)sensorNom*2;
    g.drawLine(0, ny, w, ny);

    if (trace.isEmpty()) return;
    double num = trace.elementAt(0);
    int x = 0, oy = (int)(num*2),
        y;
    g.setColor(Color.blue);                         //trace
    Enumeration<Double> pts = trace.elements();
    while (pts.hasMoreElements()) {
      num = pts.nextElement();
      y = (int)(num*2);
      g.drawLine(x, hy-oy, x+1, hy-y);
      oy = y; x++;
    }
  } //end paintComponent

} //end class
