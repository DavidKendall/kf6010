/*
 * Computation of worst-case response times of a set of tasks, each with
 * Computation time C, period T, Deadline D.
 * The response time t.r of each task t is a (fixed point) solution of
 *    t.r = t.C + sum_{u hp t}(ceil((t.r)/u.T)*u.C)   ...............(1)
 *
 * Tasks are input to an array in priority order (hi -> lo). So for task
 * t in the array, the sum in (1) above is over all tasks u earlier than t
 * in the array.
 *
 * The equations (an instance of (1) for each task in the set) solved
 * iteratively by setting for each t, t.r = sum_{u hpOr= t}(u.C) and then
 * repeatedly using equation (1) so compute a new set of r's from a
 * previous set, until no r values change.
 *
 * If at any stage, for some task t, t.r >= t.T, the system is
 * unschedulable.
 *
 * There are run-time options to sort task set into rate-monotonic order or
 * deadline-monotonic order
 *
 * Usage: java RespTime <data file> [r|d]
 *   - use option r to sort into rate-monotonic order.
 *   - d to sort into deadline-monotonic order.
 */
import java.util.*;
import java.io.*;

public class RespTime {
  static final int NONE=0, RM=1, DM=2;
  static int mode = NONE;

  class Task implements Comparable<Task> {
    String name;
    int C, T, D, r, nr;

    public Task(String nm, int nC, int nT, int nD) {
      name = nm;
      C = nC; T = nT; D = nD;
      r = 0; nr = 0;
    }

    public String toString() {
      return String.format("%s(C=%d, T=%d, D=%d): r = %d", name, C, T, D, r);
    }

    //In RM mode, sort order is T then D; in DM mode, D then T
    public int compareTo(Task other) {
      if (mode == DM)
        return D == other.D? T - other.T : D - other.D;
      else if (mode == RM)
        return T == other.T? D - other.D : T - other.T;
      else
        return 0;
    }
  };

  ArrayList<Task> tsks = new ArrayList<Task>();

  public void getData(String path) {
    try {
      FileReader file = new FileReader(path);
      // tokens in a line of the text file
      String nm;
      int rC, rT, rD;
      StreamTokenizer inputStream = new StreamTokenizer(file);
      inputStream.wordChars(0x21,0x7F);
      inputStream.commentChar('/');
      int tokenType = inputStream.nextToken();

      while (tokenType != StreamTokenizer.TT_EOF) {
        nm =      inputStream.sval; inputStream.nextToken();
        rC = (int)inputStream.nval; inputStream.nextToken();
        rT = (int)inputStream.nval; inputStream.nextToken();
        rD = (int)inputStream.nval;
        tokenType = inputStream.nextToken();
        tsks.add(new Task(nm, rC, rT, rD));
      }
      file.close();   
      System.out.println("Tasks read from file:");
      list();
    } catch (IOException ex) {
      System.err.println("Could not read data file");
    }
  }  

  public void list() {
    for (Task t: tsks)
      System.out.println(t.toString());
    System.out.println();
  }

  double computeUtn() {
    double usg = 0.0;
    for (Task t: tsks)
      usg += (double)t.C/t.T;
    System.out.printf("Total utilisation = %f\n", usg);
    return usg;
  }

  //Assumes tasks are stored in priority order, highest-priority-first.
  public void solve() {
    int sum = 0;               //initialise all r-approximations
    for (Task t: tsks) {
      sum += t.C;
      t.r = sum;
    }

    boolean converged, unschedbl;
    int itnCt = 0, nrt;
    System.out.println("Response-time computation:");
    do {
      for (Task t: tsks) {
        t.nr =t.r;
      }
      converged = true;
      unschedbl = false;
      itnCt++;
      System.out.println("Iteration " + itnCt + ":");
      for (Task t: tsks) {
        sum = 0; 
        for (Task u: tsks) {
          if (tsks.indexOf(u) >= tsks.indexOf(t))
            break;
          sum += ceil(t.nr, u.T) * u.C;
        }
        t.r =t.C + sum;

        converged = converged && (t.r == t.nr);
        unschedbl = unschedbl || (t.r > t.T);
        System.out.println(t);
      }
    } while (!converged && !unschedbl);

    if (unschedbl)
      System.out.println("The system could not be scheduled.");
    if (converged)
      System.out.printf("Convergence after %d iterations.\n", itnCt);
    for (Task t: tsks)
      if (t.r > t.T)
        System.out.printf("Task %s is unschedulable.\n", t.name);
    for (Task t: tsks)
      if (t.r > t.D)
        System.out.printf("WARNING Task %s will miss deadline.\n", t.name);
    System.out.println();
  }

  private int ceil(int a, int b) { //ceil(a/b)
    int c = a / b;
    if (a%b != 0) c++;
    return c;
  }

  public static void main(String[] args) {
    if (args.length < 1) {
      System.out.println("Usage: java RespTime <data file> [r|d]");
      System.out.println("- use option r to sort into rate-monotonic order.");
      System.out.println("- d to sort into deadline-monotonic order.");
      return;
    }  
    RespTime app = new RespTime();
    app.getData(args[0]);

    if (args.length >= 2) {
      if (args[1].charAt(0) == 'r')
         app.mode = RM;
      else if (args[1].charAt(0) == 'd')
         app.mode = DM;
      else
         app.mode = NONE;
    }
    if (app.mode != NONE) {
      Collections.sort(app.tsks);
      System.out.println("Sorted task list:");
      app.list();
    }
    app.computeUtn(); System.out.println();

    app.solve();
  }
}

 
