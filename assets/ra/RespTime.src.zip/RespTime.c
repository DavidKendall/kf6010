/*
 * Computation of worst-case response times of a set of tasks, each with
 * Computation time C, period T, Deadline D.
 * The response time t.r of each task t is a (fixed point) solution of
 *    t->r = t->C + sum_{u hp t}(ceil((t->r)/u->T)*u->C)   .........(1)
 *
 * Tasks are input to an array in priority order (hi -> lo). So for task
 * t in the array, the sum in (1) above is over all tasks u earlier than t
 * in the array.
 *
 * The equations (an instance of (1) for each task in the set) solved
 * iteratively by setting for each t, t->r = sum_{u hpOr= t}(u->C) and then
 * repeatedly using equation (1) so compute a new set of r's from a
 * previous set, until no r values change.
 *
 * If at any stage, for some task t, t->r >= t->T, the system is
 * unschedulable.

 * Usage: %s <data file> [r|d]\n", argv[0])
 *  - use option r to sort into rate-monotonic order.
 *  - d to sort into deadline-monotonic order.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TRUE 1
#define FALSE 0

typedef struct {
  char * name;
  int C, T, D, r, nr;
} Task;

Task * newTask(char * nm, int nC, int nT, int nD) {
  Task * t = (Task *)malloc(sizeof (Task));
  t->name = (char *)malloc(strlen(nm));
  strcpy(t->name, nm);
  t->C = nC; t->T = nT; t->D = nD;
  t->r = 0; t->nr = 0;
  return t;
}

void displayTask(Task *t) {
  printf("%s(C=%d, T=%d, D=%d): r = %d\n", t->name, t->C, t->T, t->D, t->r);
}

#define NUMTSKS 20
Task * tsks[NUMTSKS];
int numTsks = 0;

void displayTaskList(int lim) {
  int i;
  for (i=0; i<lim; i++)
    displayTask(tsks[i]);
  printf("\n");
}

double computeUtn(int lim) {
  double u = 0.0;
  int i; Task *t;
  for (i=0; i<lim; i++) {
    t = tsks[i];
    if (t->T == 0) {
      fprintf(stderr, "Zero divisor!\n");
      break;
    }
    u += (double)t->C/t->T;
  }
  return u;
}

//trim leading spaces etc (ascii <= ' ') from a string
void trim(char * s) {
  char * ns = s;
  while (*ns != '\0' && *ns <= ' ')
    ns++; //find first nonspace
  int i;
  for (i = 0; ns[i] != '\0'; i++)
    s[i] = ns[i]; //copy chars
  s[i] = '\0'; //terminate
}

//Read task set in from data file: lines of (name, C, T, D)
int getData(char * path) {
  char line[80] = "";
  FILE * file = fopen(path, "r");
  char nm[40];    // tokens in a line of the text file
  int rC, rT, rD;
  int tskCtr = 0;

  if (file == NULL) {
    perror("Could not read input file\n");
    exit(1);
  }
  fgets(line, 80, file); trim(line);
  while (strlen(line) > 0 && tskCtr < NUMTSKS) {
    if (line[0] == '/' || line[0] <= ' ') { //ignore these lines
      line[0] = 0;
      fgets(line, 80, file); trim(line);
      continue;
    }
    sscanf(line, "%s %d %d %d", nm, &rC, &rT, &rD);
    tsks[tskCtr] = newTask(nm, rC, rT, rD);
    tskCtr++;
    line[0] = 0;
    fgets(line, 80, file); trim(line);
  }
  fclose(file);
  printf("Tasks read from file:\n");
  displayTaskList(tskCtr);
  return tskCtr;
}  

//Sort tasks: option 'T': by "rate" (period, T) then deadline D, or
//            option 'D': by D then by T
//Assuming task set is smallish, Selection sort will do.
//First, a subsidiary function to find "largest" task in (0..lim):
int findLgst(int lim, char key) {
  Task *lgst = tsks[0], *t;
  int iLgst = 0, i, vd, vt,
      keyD = lgst->D, keyT = lgst->T;
  for (i=1; i<=lim; i++) {
    t = tsks[i]; vd = t->D; vt = t->T;
    if ((key=='D' && (vd > keyD || (vd == keyD && vt > keyT)))
      ||(key=='T' && (vt > keyT || (vt == keyT && vd > keyD)))) {
        lgst = t; keyD = vd; keyT = vt; iLgst = i;
    }
  }
  return iLgst;
}

//Sel sort using this subsidiary function:
void sort(int sz, char key) {
  Task * tmp;
  int pos, idx;
  for (idx = sz-1; idx > 0; idx--) {
    pos = findLgst(idx, key);
    if (idx != pos) { //swap
      tmp = tsks[idx]; tsks[idx] = tsks[pos]; tsks[pos] = tmp; 
    }
  }
}

//Helper function -- ceiling for quotient of two integers
int ceilg(int a, int b) { //ceil(a/b)
  int c = a / b;
  if (a%b != 0) c++;
  return c;
}

//Solver: assumes tasks are stored highest-priority-first.
void solve() {
  int converged, unschedbl;
  int itnCt = 0, k, j;
  Task * t, * u;

  int sum = 0;               //initialise all r-approximations
  for (k=0 ; k < numTsks; k++) {
    sum += tsks[k]->C;
    tsks[k]->r = sum;
  }

  do {
    for (k=0 ; k < numTsks; k++) {
      t = tsks[k];
      t->nr = t->r;
    }
    converged = TRUE;
    unschedbl = FALSE;
    itnCt++;
    printf("Iteration %d:\n", itnCt);
    for (k = 0; k < numTsks; k++) {
      t = tsks[k];
      sum = 0; 
      for (j = 0; j < k; j++) { //just higher pri tasks
        u = tsks[j];
        sum += ceilg(t->nr, u->T) * u->C;
      }
      t->r =t->C + sum;

      converged = converged && (t->r == t->nr);
      unschedbl = unschedbl || (t->r > t->T);
      displayTask(t);
    }
  } while (!converged && !unschedbl);

  if (unschedbl)
    printf("The system could not be scheduled.\n");
  if (converged)
    printf("Convergence after %d iterations.\n", itnCt);
  for (k = 0; k < numTsks; k++) {
    t = tsks[k];
    if (t->r > t->T)
      printf("Task %s is unschedulable.\n", t->name);
  }
  for (k = 0; k < numTsks; k++) {
    t = tsks[k];
    if (t->r > t->D)
      printf("WARNING Task %s will miss its deadline.\n", t->name);
  }
}

int main(int argc, char ** argv) {
  if (argc <= 1) {
    printf("Usage: %s <data file> [r|d]\n", argv[0]);
    printf("- use option r to sort into rate-monotonic order.\n");
    printf("- d to sort into deadline-monotonic order.\n");
    return 0;
  }  
  numTsks = getData(argv[1]);
  printf("Got %d tasks\n", numTsks);

  if (numTsks == 0) {
    printf("No tasks!\n");
    return 0;
  }

  printf("Utilisation = %f\n\n", computeUtn(numTsks));

  if (argc >= 3) {
    if (argv[2][0]=='d')
      sort(numTsks, 'D');
    else if (argv[2][0]=='r')
      sort(numTsks, 'T');
  
    printf("Sorted task list:\n");
    displayTaskList(numTsks);    
  }

  solve();
  return 0;
}

