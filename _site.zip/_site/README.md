# Embedded systems engineering

This repository contains the source of the module website for
<a href="http://hesabu.net/cm0605">CM0605 Embedded systems engineering</a>
